# Save the student and classmate values in a dictionary
students = {
    "studentName": "Lewis Fonsi",
    "classMate": "Andrea Andres"
}

# Save the lengths of the studentName and classMate in a list
name_lengths = [len(students["studentName"]), len(students["classMate"])]

#Define a callable function that includes if...elif...esle condition
def check_conditions(value):
    if value == "student":
        return "This is the student."
    elif value == "classmate":
        return "This is the classmate."
    else:
        return "Unknown role."

# Call the function
def quizTwo(user_name):
    print(check_conditions(user_name))

#Reverse the order of the sorted classNumber list
class_numbers = [10, 3, 8, 15, 7]
class_numbers.sort(reverse=True)  
print("Sorted classNumbers in descending order:", class_numbers)

#Prompt user for input and pass that input to the quizTwo function.
user_input = input("Enter the role (student/classmate/other): ")
quizTwo(user_input)